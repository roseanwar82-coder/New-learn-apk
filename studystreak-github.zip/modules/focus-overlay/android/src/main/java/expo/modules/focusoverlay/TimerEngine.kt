package expo.modules.focusoverlay

import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Kotlin port of src/features/session/timer.ts. Field names and semantics match
 * exactly so the JSON the service persists can be handed straight to the TS
 * engine (tick/remainingMs/...) in the app. Time values are SystemClock.elapsedRealtime().
 */
data class TimerState(
  val status: String, // running | paused | completed | aborted
  val plannedMs: Long,
  val bankedMs: Long,
  val segmentStart: Long?,
  val pausedAt: Long?,
  val pauseCount: Int,
  val totalPausedMs: Long,
  val lastSeen: Long,
  val maxPauseMs: Long,
) {
  val isFinished: Boolean get() = status == "completed" || status == "aborted"

  fun toJson(): JSONObject = JSONObject().apply {
    put("status", status)
    put("plannedMs", plannedMs)
    put("bankedMs", bankedMs)
    put("segmentStart", segmentStart ?: JSONObject.NULL)
    put("pausedAt", pausedAt ?: JSONObject.NULL)
    put("pauseCount", pauseCount)
    put("totalPausedMs", totalPausedMs)
    put("lastSeen", lastSeen)
    put("maxPauseMs", maxPauseMs)
  }

  companion object {
    fun fromJson(o: JSONObject): TimerState = TimerState(
      status = o.getString("status"),
      plannedMs = o.getLong("plannedMs"),
      bankedMs = o.getLong("bankedMs"),
      segmentStart = if (o.isNull("segmentStart")) null else o.getLong("segmentStart"),
      pausedAt = if (o.isNull("pausedAt")) null else o.getLong("pausedAt"),
      pauseCount = o.getInt("pauseCount"),
      totalPausedMs = o.getLong("totalPausedMs"),
      lastSeen = o.getLong("lastSeen"),
      maxPauseMs = o.getLong("maxPauseMs"),
    )
  }
}

object TimerEngine {
  const val DEFAULT_MAX_PAUSE_MS = 5 * 60_000L

  fun start(plannedMs: Long, now: Long, maxPauseMs: Long = DEFAULT_MAX_PAUSE_MS): TimerState {
    require(plannedMs > 0) { "plannedMs must be > 0" }
    return TimerState("running", plannedMs, 0L, now, null, 0, 0L, now, maxPauseMs)
  }

  private fun normalize(s: TimerState, now: Long): TimerState {
    if (now >= s.lastSeen) return s.copy(lastSeen = now)
    val seg = s.segmentStart
    if (s.status == "running" && seg != null) {
      return s.copy(
        bankedMs = s.bankedMs + max(0L, s.lastSeen - seg),
        segmentStart = now,
        lastSeen = now,
      )
    }
    if (s.status == "paused") return s.copy(pausedAt = now, lastSeen = now)
    return s.copy(lastSeen = now)
  }

  fun focusedMs(s: TimerState, now: Long): Long {
    var total = s.bankedMs
    val seg = s.segmentStart
    if (s.status == "running" && seg != null) total += max(0L, now - seg)
    return min(total, s.plannedMs)
  }

  fun remainingMs(s: TimerState, now: Long): Long {
    if (s.status == "completed") return 0L
    return max(0L, s.plannedMs - focusedMs(s, now))
  }

  fun tick(input: TimerState, now: Long): TimerState {
    if (input.isFinished) return input
    val s = normalize(input, now)
    if (s.status == "running" && focusedMs(s, now) >= s.plannedMs) {
      return s.copy(status = "completed", bankedMs = s.plannedMs, segmentStart = null)
    }
    val pa = s.pausedAt
    if (s.status == "paused" && pa != null && now - pa > s.maxPauseMs) {
      return s.copy(status = "aborted", totalPausedMs = s.totalPausedMs + (now - pa), pausedAt = null)
    }
    return s
  }

  fun pause(input: TimerState, now: Long): TimerState {
    val s = tick(input, now)
    if (s.status != "running") return s
    return s.copy(
      status = "paused",
      bankedMs = focusedMs(s, now),
      segmentStart = null,
      pausedAt = now,
      pauseCount = s.pauseCount + 1,
    )
  }

  fun resume(input: TimerState, now: Long): TimerState {
    val s = tick(input, now)
    val pa = s.pausedAt
    if (s.status != "paused" || pa == null) return s
    return s.copy(
      status = "running",
      segmentStart = now,
      totalPausedMs = s.totalPausedMs + (now - pa),
      pausedAt = null,
    )
  }

  fun extend(input: TimerState, addMs: Long, now: Long): TimerState {
    if (addMs <= 0) return input
    val s = tick(input, now)
    if (s.status != "running" && s.status != "paused") return s
    return s.copy(plannedMs = s.plannedMs + addMs)
  }

  fun stop(input: TimerState, now: Long): TimerState {
    val s = tick(input, now)
    if (s.isFinished) return s
    val pa = s.pausedAt
    val extraPaused = if (s.status == "paused" && pa != null) now - pa else 0L
    return s.copy(
      status = "aborted",
      bankedMs = focusedMs(s, now),
      segmentStart = null,
      totalPausedMs = s.totalPausedMs + extraPaused,
      pausedAt = null,
    )
  }
}
