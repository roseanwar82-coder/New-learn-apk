package expo.modules.focusoverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/**
 * Invisible activity whose only job is to show the system screen-capture consent
 * dialog and hand the result to OverlayService. On Android 14+ pick "Entire screen"
 * (choosing a single app only captures that app).
 */
class ScreenCaptureActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    @Suppress("DEPRECATION")
    startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
  }

  @Suppress("DEPRECATION")
  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    val svc = Intent(this, OverlayService::class.java)
    if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
      svc.action = OverlayService.ACTION_PROJECTION_GRANTED
      svc.putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
      svc.putExtra(OverlayService.EXTRA_RESULT_DATA, data)
    } else {
      svc.action = OverlayService.ACTION_PROJECTION_DENIED
    }
    startService(svc)
    finish()
  }

  private companion object {
    const val REQ = 7731
  }
}
