# Build the APK on GitHub (no computer tools needed)

1. Unzip this file.
2. On github.com, create a **new repository** (private is fine).
3. Click **uploading an existing file**, then drag in **everything inside the unzipped folder**.
   - Make sure the hidden `.github` folder goes up too. If your file manager hides it, turn on "show hidden files".
   - If you can't get `.github` uploaded: in the repo go to **Actions → set up a workflow yourself**, name it `build-apk.yml`, and paste the contents of `build-apk.yml` from this folder's root.
4. Commit. Open the **Actions** tab. The "Build APK" run starts by itself (or click **Run workflow**). It takes about 15-25 minutes.
5. When it turns green, open the run and download **StudyStreak-apk** from "Artifacts" at the bottom. Unzip it to get `StudyStreak.apk`.
6. Send the APK to your phone and install it (Android will ask you to allow installs from that source).
7. In the app: finish onboarding, grant permissions, then in Settings paste your API key for Circle to solve.

If the run fails (red), open it, expand the failed step, and paste the last 40 lines of the log to Claude.
Test/type-check problems show up as yellow warnings and don't stop the build.
