package expo.modules.focusoverlay

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Process
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

/** Packages that are never blocked, even if JS sends them. */
private val NEVER_BLOCK = setOf(
  "com.android.settings",
  "com.android.systemui",
  "com.android.phone",
  "com.android.dialer",
  "com.google.android.dialer",
  "com.samsung.android.dialer",
  "com.android.emergency",
  "com.google.android.apps.safetyhub",
)

fun hasUsageAccess(c: Context): Boolean {
  val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
  @Suppress("DEPRECATION")
  val mode = if (Build.VERSION.SDK_INT >= 29) {
    ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
  } else {
    ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
  }
  return mode == AppOpsManager.MODE_ALLOWED
}

/** Launchable apps as a JSON array of {packageName,label}, sorted by label. */
fun listInstalledApps(c: Context): String {
  val pm = c.packageManager
  val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
  val seen = HashSet<String>()
  val rows = ArrayList<Pair<String, String>>()
  for (ri in pm.queryIntentActivities(launcher, 0)) {
    val pkg = ri.activityInfo.packageName
    if (pkg == c.packageName || pkg in NEVER_BLOCK || !seen.add(pkg)) continue
    rows.add(pkg to ri.loadLabel(pm).toString())
  }
  rows.sortBy { it.second.lowercase() }
  val out = JSONArray()
  for ((pkg, label) in rows) out.put(JSONObject().put("packageName", pkg).put("label", label))
  return out.toString()
}

/**
 * Polls UsageStatsManager for the foreground app while a session is running.
 * Detection latency is ~0.6s, so a blocked app can flash briefly before the
 * interstitial covers it. Callbacks run on [handler]'s thread (main).
 */
class BlockingController(
  private val ctx: Context,
  private val handler: Handler,
  private val isActive: () -> Boolean,
  private val onBlocked: (pkg: String) -> Unit,
  private val onClear: () -> Unit,
) {
  private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
  private var running = false
  private var foreground: String? = null
  private var lastQuery = 0L
  private val snoozed = HashMap<String, Long>()

  /** Set when the user takes the hard-mode emergency exit; lasts until the session ends. */
  @Volatile
  var disabledForSession = false

  fun start() {
    if (running) return
    running = true
    foreground = null
    lastQuery = System.currentTimeMillis() - 5_000
    handler.post(poll)
  }

  fun stop() {
    running = false
    handler.removeCallbacks(poll)
    foreground = null
    snoozed.clear()
  }

  fun snooze(pkg: String, ms: Long) {
    snoozed[pkg] = SystemClock.uptimeMillis() + ms
  }

  private val poll = object : Runnable {
    override fun run() {
      if (!running) return
      try {
        check()
      } catch (e: Exception) {
        // usage access revoked mid-session or transient failure: skip this cycle
      }
      if (running) handler.postDelayed(this, 600)
    }
  }

  private fun check() {
    val now = System.currentTimeMillis()
    val events = usm.queryEvents(lastQuery, now)
    val e = UsageEvents.Event()
    while (events.hasNextEvent()) {
      events.getNextEvent(e)
      // MOVE_TO_FOREGROUND (API < 29) and ACTIVITY_RESUMED (API 29+) share value 1.
      if (e.eventType == 1) foreground = e.packageName
    }
    lastQuery = now - 1_000

    val pkg = foreground
    if (!isActive() || disabledForSession || pkg == null) {
      onClear()
      return
    }
    if (pkg == ctx.packageName || pkg in NEVER_BLOCK || pkg !in BlockStore.packages(ctx)) {
      onClear()
      return
    }
    val until = snoozed[pkg]
    if (until != null && SystemClock.uptimeMillis() < until) {
      onClear()
      return
    }
    onBlocked(pkg)
  }
}
