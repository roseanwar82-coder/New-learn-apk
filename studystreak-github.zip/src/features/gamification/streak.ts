import { DayKey, addDays, diffDays } from '../../core/dayKey';

export const FREEZE_EARN_EVERY = 7;
export const MAX_FREEZE_TOKENS = 2;
export const RECOVERY_COOLDOWN_DAYS = 30;
export const RECOVERY_GOAL_MULTIPLIER = 2;

export interface StreakState {
  current: number;
  longest: number;
  lastQualifiedDay: DayKey | null;
  freezeTokens: number;
  freezesUsed: DayKey[];
  lastRecoveryDay: DayKey | null;
}

export const initialStreak: StreakState = {
  current: 0,
  longest: 0,
  lastQualifiedDay: null,
  freezeTokens: 0,
  freezesUsed: [],
  lastRecoveryDay: null,
};

export type StreakOutcome =
  | 'started'
  | 'continued'
  | 'frozen'
  | 'recovered'
  | 'reset'
  | 'unchanged';

function canRecover(state: StreakState, day: DayKey): boolean {
  return (
    state.lastRecoveryDay === null ||
    diffDays(day, state.lastRecoveryDay) >= RECOVERY_COOLDOWN_DAYS
  );
}

/**
 * Call when a day's total focus first reaches the streak threshold.
 * Gap handling, in order: auto-spend freeze tokens, then 2x-goal recovery
 * (exactly one missed day, once per cooldown), otherwise the streak resets.
 */
export function applyQualifiedDay(
  state: StreakState,
  day: DayKey,
  dayFocusMs: number,
  goalMs: number,
): { state: StreakState; outcome: StreakOutcome } {
  const last = state.lastQualifiedDay;
  if (last === day) return { state, outcome: 'unchanged' };
  if (last !== null && diffDays(day, last) < 0) return { state, outcome: 'unchanged' };

  const next: StreakState = { ...state, freezesUsed: [...state.freezesUsed] };
  let outcome: StreakOutcome;

  if (last === null) {
    next.current = 1;
    outcome = 'started';
  } else {
    const missed = diffDays(day, last) - 1;
    if (missed === 0) {
      next.current = state.current + 1;
      outcome = 'continued';
    } else if (state.freezeTokens >= missed) {
      next.freezeTokens = state.freezeTokens - missed;
      for (let i = 1; i <= missed; i++) next.freezesUsed.push(addDays(last, i));
      next.current = state.current + 1;
      outcome = 'frozen';
    } else if (
      missed === 1 &&
      dayFocusMs >= goalMs * RECOVERY_GOAL_MULTIPLIER &&
      canRecover(state, day)
    ) {
      next.current = state.current + 1;
      next.lastRecoveryDay = day;
      outcome = 'recovered';
    } else {
      next.current = 1;
      outcome = 'reset';
    }
  }

  next.lastQualifiedDay = day;
  next.longest = Math.max(state.longest, next.current);
  if (next.current > state.current && next.current % FREEZE_EARN_EVERY === 0) {
    next.freezeTokens = Math.min(MAX_FREEZE_TOKENS, next.freezeTokens + 1);
  }
  return { state: next, outcome };
}

export interface LiveStreak {
  /** Streak value to display right now (0 if already broken). */
  value: number;
  qualifiedToday: boolean;
  /** Today still needs to qualify to keep the streak going. */
  atRisk: boolean;
  /** A 2x-goal day today would restore a one-day miss. */
  recoverable: boolean;
}

/** What the UI should show for `today`, before today's progress is counted. */
export function liveStreak(state: StreakState, today: DayKey): LiveStreak {
  const last = state.lastQualifiedDay;
  if (last === null) return { value: 0, qualifiedToday: false, atRisk: false, recoverable: false };

  const gap = diffDays(today, last);
  if (gap <= 0) return { value: state.current, qualifiedToday: true, atRisk: false, recoverable: false };
  if (gap === 1) return { value: state.current, qualifiedToday: false, atRisk: true, recoverable: false };

  const missed = gap - 1;
  if (state.freezeTokens >= missed) {
    return { value: state.current, qualifiedToday: false, atRisk: true, recoverable: false };
  }
  if (missed === 1 && canRecover(state, today)) {
    return { value: state.current, qualifiedToday: false, atRisk: true, recoverable: true };
  }
  return { value: 0, qualifiedToday: false, atRisk: false, recoverable: false };
}
