# StudyStreak (Android)

Deep-study focus app: floating timer over every app, app blocking, "Circle to solve" AI help, focus games, XP / levels / streaks / badges. Expo + React Native + a Kotlin native module.

## Status: code-complete, not yet built on a device

- **Tested here:** all game, XP, streak, badge, timer, blocking-config, stats and session-sync logic (81 tests). The pure logic also passes a strict TypeScript check.
- **NOT verified here:** the Kotlin native module (never compiled) and the React Native screens (never run). My sandbox had no npm registry, Android SDK or device. Expect a few fixes on the first real build. See `modules/focus-overlay/README.md` for the on-phone checklist.

## Get an APK

Needs a computer with Node 20+ and an Expo account.

```bash
bash scripts/bootstrap.sh          # creates ../studystreak-app with everything copied in
cd ../studystreak-app
npm test                           # logic tests
npx tsc --noEmit                   # type check against the real library types
npm i -g eas-cli && eas login
eas build -p android --profile preview   # cloud build, gives you an installable .apk
```

Install the APK on your phone (allow "install unknown apps"). Then: open the app, finish onboarding, grant permissions, and in Settings paste your API key for Circle to solve.

## What's in it

| Area | Where |
|---|---|
| Screens (Expo Router) | `src/app/*` : Today, Train, Stats, Settings, session setup/active/complete, game player, apps picker, permissions, onboarding |
| Persisted state (AsyncStorage) | `src/state/store.ts` |
| Timer state machine (monotonic clock, reboot-safe) | `src/features/session/timer.ts` + Kotlin port `TimerEngine.kt` |
| XP, levels, streaks (freeze + recovery), badges | `src/features/gamification/*` |
| Five focus games (logic + UI) | `src/features/games/*` |
| Block config + never-block list | `src/features/blocking/config.ts` |
| Native: floating timer, capture, lasso, AI sheet, app blocking | `modules/focus-overlay/` |

## Tests without installing anything

    bun test

Test files use plain `describe/it/expect`, so they also run under Jest (`jest-expo`) after bootstrap.
