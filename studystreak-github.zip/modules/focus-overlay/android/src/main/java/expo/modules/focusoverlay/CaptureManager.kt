package expo.modules.focusoverlay

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.SystemClock

/**
 * Holds ONE MediaProjection + VirtualDisplay for the whole session (Android 14+
 * allows a projection to create a single VirtualDisplay, and consent is
 * per-session). Frames are kept as "latest Image"; grab() converts it on demand.
 * All callbacks run on [handler] (main looper).
 */
class CaptureManager(
  private val ctx: Context,
  private val handler: Handler,
) {
  private var projection: MediaProjection? = null
  private var display: VirtualDisplay? = null
  private var reader: ImageReader? = null
  private var width = 0
  private var height = 0
  private var latest: Image? = null
  private val lock = Any()

  val isActive: Boolean get() = projection != null

  fun start(resultCode: Int, data: Intent, w: Int, h: Int, dpi: Int, onStopped: () -> Unit) {
    val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    val p = mpm.getMediaProjection(resultCode, data)
      ?: throw IllegalStateException("MediaProjection unavailable")

    // Required on Android 14+ before createVirtualDisplay.
    p.registerCallback(
      object : MediaProjection.Callback() {
        override fun onStop() {
          release()
          onStopped()
        }
      },
      handler,
    )
    projection = p
    width = w
    height = h
    val r = newReader(w, h)
    display = p.createVirtualDisplay(
      "focus-capture", w, h, dpi,
      DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
      r.surface, null, handler,
    )
  }

  private fun newReader(w: Int, h: Int): ImageReader {
    val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
    r.setOnImageAvailableListener({ rd ->
      val img = try {
        rd.acquireLatestImage()
      } catch (e: Exception) {
        null
      }
      if (img != null) {
        synchronized(lock) {
          latest?.close()
          latest = img
        }
      }
    }, handler)
    reader = r
    return r
  }

  /** Call before grab() so rotation / size changes don't produce a mismatched frame. */
  fun ensureSize(w: Int, h: Int, dpi: Int) {
    val d = display ?: return
    if (w == width && h == height) return
    synchronized(lock) {
      latest?.close()
      latest = null
    }
    val old = reader
    val r = newReader(w, h)
    d.resize(w, h, dpi)
    d.surface = r.surface
    old?.close()
    width = w
    height = h
  }

  /** Delivers the most recent screen frame as a Bitmap, or null on timeout. */
  fun grab(timeoutMs: Long = 1500L, cb: (Bitmap?) -> Unit) {
    val deadline = SystemClock.uptimeMillis() + timeoutMs
    lateinit var poll: Runnable
    poll = Runnable {
      val bmp = synchronized(lock) { latest?.let { toBitmap(it) } }
      when {
        bmp != null -> cb(bmp)
        SystemClock.uptimeMillis() >= deadline -> cb(null)
        else -> handler.postDelayed(poll, 50)
      }
    }
    handler.post(poll)
  }

  private fun toBitmap(img: Image): Bitmap {
    val plane = img.planes[0]
    val pixelStride = plane.pixelStride
    val rowPadding = plane.rowStride - pixelStride * width
    val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
    padded.copyPixelsFromBuffer(plane.buffer)
    if (rowPadding == 0) return padded
    val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
    padded.recycle()
    return cropped
  }

  fun release() {
    synchronized(lock) {
      latest?.close()
      latest = null
    }
    display?.release()
    display = null
    reader?.close()
    reader = null
    val p = projection
    projection = null
    try {
      p?.stop()
    } catch (e: Exception) {
      // already stopped
    }
  }
}
