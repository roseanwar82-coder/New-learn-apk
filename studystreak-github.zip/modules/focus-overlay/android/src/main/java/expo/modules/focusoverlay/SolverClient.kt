package expo.modules.focusoverlay

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Streams answers from the Anthropic Messages API (or a proxy exposing the same
 * shape at baseUrl). Callbacks run on a background thread; the caller must hop
 * to the main thread before touching views. One instance = one conversation.
 */
class SolverClient(private val cfg: SolverConfig) {
  private val history = JSONArray()

  @Volatile
  private var busy = false

  val isBusy: Boolean get() = busy

  fun ask(
    imageBase64: String?,
    text: String,
    onDelta: (String) -> Unit,
    onDone: () -> Unit,
    onError: (String) -> Unit,
  ) {
    if (busy) return
    busy = true

    val content = JSONArray()
    if (imageBase64 != null) {
      content.put(
        JSONObject()
          .put("type", "image")
          .put(
            "source",
            JSONObject()
              .put("type", "base64")
              .put("media_type", "image/jpeg")
              .put("data", imageBase64),
          ),
      )
    }
    content.put(JSONObject().put("type", "text").put("text", text))
    val userMsg = JSONObject().put("role", "user").put("content", content)

    Thread {
      var conn: HttpURLConnection? = null
      var failure: String? = null
      val answer = StringBuilder()
      try {
        val messages = JSONArray()
        for (i in 0 until history.length()) messages.put(history.get(i))
        messages.put(userMsg)

        val body = JSONObject()
          .put("model", cfg.model)
          .put("max_tokens", 2048)
          .put("stream", true)
          .put("system", systemPrompt())
          .put("messages", messages)

        val c = URL(cfg.baseUrl.trimEnd('/') + "/v1/messages").openConnection() as HttpURLConnection
        conn = c
        c.requestMethod = "POST"
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("anthropic-version", "2023-06-01")
        if (cfg.apiKey.isNotEmpty()) c.setRequestProperty("x-api-key", cfg.apiKey)
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        if (code !in 200..299) {
          val err = c.errorStream?.bufferedReader()?.readText() ?: ""
          failure = describeError(code, err)
        } else {
          val reader = c.inputStream.bufferedReader()
          while (failure == null) {
            val line = reader.readLine() ?: break
            if (!line.startsWith("data:")) continue
            val data = line.removePrefix("data:").trim()
            if (data.isEmpty() || data == "[DONE]") continue
            val ev = JSONObject(data)
            when (ev.optString("type")) {
              "content_block_delta" -> {
                val d = ev.optJSONObject("delta")
                if (d != null && d.optString("type") == "text_delta") {
                  val t = d.optString("text")
                  answer.append(t)
                  onDelta(t)
                }
              }
              "error" -> failure = ev.optJSONObject("error")?.optString("message") ?: "Stream error"
            }
          }
        }
      } catch (e: Exception) {
        failure = e.message ?: "Network error"
      } finally {
        conn?.disconnect()
      }

      if (failure == null) {
        history.put(userMsg)
        history.put(
          JSONObject().put("role", "assistant").put(
            "content",
            JSONArray().put(JSONObject().put("type", "text").put("text", answer.toString())),
          ),
        )
        busy = false
        onDone()
      } else {
        busy = false
        onError(failure)
      }
    }.start()
  }

  private fun systemPrompt(): String {
    val style = if (cfg.detail == "short") {
      "Be concise: give the final answer with at most a few short lines of working."
    } else {
      "Show clear numbered steps, then finish with a line starting with 'Answer:'."
    }
    return "You are a study assistant. The user sends a cropped screenshot containing a question " +
      "(any subject, any format) and may ask follow-ups. Solve it directly. $style " +
      "If part of the image is unreadable or ambiguous, state your assumption. " +
      "Write math in plain text, no LaTeX."
  }

  private fun describeError(code: Int, body: String): String {
    val msg = try {
      JSONObject(body).optJSONObject("error")?.optString("message")
    } catch (e: Exception) {
      null
    }
    return when (code) {
      401, 403 -> "API key was rejected. Check it in settings."
      429 -> "Rate limited. Try again in a moment."
      else -> msg ?: "Request failed (HTTP $code)"
    }
  }
}
