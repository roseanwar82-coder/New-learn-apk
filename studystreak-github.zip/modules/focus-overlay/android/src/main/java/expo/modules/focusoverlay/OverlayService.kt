package expo.modules.focusoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Foreground service that owns, independent of the React Native UI:
 *  - the session timer (persisted; survives the app being killed)
 *  - the floating bubble / expandable panel (Pause, Resume, +5 min, Stop, Circle to solve)
 *  - screen capture, the lasso, and the streaming answer sheet
 */
class OverlayService : Service() {
  companion object {
    const val ACTION_START = "expo.modules.focusoverlay.START"
    const val ACTION_STOP = "expo.modules.focusoverlay.STOP"
    const val ACTION_PROJECTION_GRANTED = "expo.modules.focusoverlay.PROJECTION_GRANTED"
    const val ACTION_PROJECTION_DENIED = "expo.modules.focusoverlay.PROJECTION_DENIED"
    const val EXTRA_PLANNED_MS = "plannedMs"
    const val EXTRA_RESULT_CODE = "resultCode"
    const val EXTRA_RESULT_DATA = "resultData"

    private const val CHANNEL_ID = "focus_overlay"
    private const val NOTIF_ID = 4101
    private const val TAG = "FocusOverlay"

    private val ACCENT = 0xFF8B7CFF.toInt()
    private val CARD = 0xF2121218.toInt()
    private val PILL = 0xFF262633.toInt()
    private val MUTED = 0xFF9A9AB0.toInt()

    fun start(ctx: Context, plannedMs: Long) {
      val i = Intent(ctx, OverlayService::class.java)
        .setAction(ACTION_START)
        .putExtra(EXTRA_PLANNED_MS, plannedMs)
      if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
    }

    fun stop(ctx: Context) {
      ctx.startService(Intent(ctx, OverlayService::class.java).setAction(ACTION_STOP))
    }
  }

  private lateinit var wm: WindowManager
  private lateinit var capture: CaptureManager
  private val main = Handler(Looper.getMainLooper())
  private var destroyed = false

  // timer
  private var timer: TimerState? = null
  private var finishedUi = false

  // bubble + panel
  private var bubble: TextView? = null
  private var bubbleLp: WindowManager.LayoutParams? = null
  private var panel: LinearLayout? = null
  private var panelLp: WindowManager.LayoutParams? = null
  private var panelTime: TextView? = null
  private var panelStatus: TextView? = null
  private var pauseBtn: TextView? = null
  private var controlsRow: LinearLayout? = null
  private var solveBtn: TextView? = null
  private var closeBtn: TextView? = null
  private var lastX = 24
  private var lastY = 320

  // solver flow
  private var pendingSolve = false
  private var lassoRoot: FrameLayout? = null
  private var lassoHint: TextView? = null
  private var sheet: SheetLayout? = null
  private var answerText: TextView? = null
  private var answerScroll: ScrollView? = null
  private var solver: SolverClient? = null
  private var firstDelta = true

  // app blocking
  private lateinit var blocking: BlockingController
  private var interstitial: FrameLayout? = null
  private var interstitialPkg: String? = null
  private var interstitialTime: TextView? = null
  private var interstitialTicker: Runnable? = null

  private val ticker = object : Runnable {
    override fun run() {
      onTick()
      if (!destroyed) main.postDelayed(this, 1000)
    }
  }

  // ───────────────────────── lifecycle ─────────────────────────

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    capture = CaptureManager(this, main)
    blocking = BlockingController(
      this, main,
      isActive = { timer?.status == "running" && !finishedUi },
      onBlocked = { pkg -> onBlockedForeground(pkg) },
      onClear = { dismissInterstitial() },
    )
    createChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_START -> handleStart(intent!!.getLongExtra(EXTRA_PLANNED_MS, 25 * 60_000L))
      ACTION_STOP -> handleEnd()
      ACTION_PROJECTION_GRANTED -> handleProjectionGranted(intent!!)
      ACTION_PROJECTION_DENIED -> {
        pendingSolve = false
        toast("Screen capture permission was declined.")
      }
      else -> {
        // Sticky restart after the process was killed: rebuild from persisted state.
        if (!restore()) {
          promote(false)
          stopSelf()
          return START_NOT_STICKY
        }
      }
    }
    return START_STICKY
  }

  override fun onDestroy() {
    destroyed = true
    main.removeCallbacksAndMessages(null)
    removeView(bubble)
    removeView(panel)
    removeView(lassoRoot)
    removeView(sheet)
    blocking.stop()
    removeView(interstitial)
    capture.release()
    super.onDestroy()
  }

  // ───────────────────────── session control ─────────────────────────

  private fun handleStart(plannedMs: Long) {
    promote(false) // must happen quickly after startForegroundService()
    if (!canDraw()) {
      OverlayBus.emit("onTimerAction", mapOf("action" to "permissionLost"))
      stopSelf()
      return
    }
    finishedUi = false
    val s = TimerEngine.start(plannedMs, SystemClock.elapsedRealtime())
    timer = s
    TimerStore.save(this, s)
    showBubble()
    restartTicker()
    BlockStore.resetAttempts(this)
    startBlocking()
    OverlayBus.emit("onTimerAction", mapOf("action" to "started"))
  }

  private fun restore(): Boolean {
    val saved = TimerStore.load(this) ?: return false
    if (saved.isFinished || !canDraw()) return false
    promote(false)
    timer = saved
    finishedUi = false
    startBlocking()
    showBubble()
    restartTicker()
    return true
  }

  /** JS asked to tear everything down. An unfinished session is recorded as stopped. */
  private fun handleEnd() {
    promote(false)
    // Service may be freshly created here (e.g. after the process was killed), so
    // fall back to the persisted timer to avoid losing the session.
    val t = timer ?: TimerStore.load(this)
    if (t != null && !t.isFinished) {
      val s = TimerEngine.stop(t, SystemClock.elapsedRealtime())
      timer = s
      finishSession(s)
    }
    shutdown()
  }

  private fun shutdown() {
    stopBlocking()
    destroyed = true
    main.removeCallbacksAndMessages(null)
    removeView(bubble); bubble = null
    removeView(panel); panel = null
    removeView(lassoRoot); lassoRoot = null
    removeView(sheet); sheet = null
    capture.release()
    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
    stopSelf()
  }

  private fun restartTicker() {
    main.removeCallbacks(ticker)
    main.post(ticker)
  }

  private fun onTick() {
    val t = timer ?: return
    if (t.isFinished) return
    val now = SystemClock.elapsedRealtime()
    val next = TimerEngine.tick(t, now)
    timer = next
    if (next.isFinished) {
      finishSession(next)
      return
    }
    TimerStore.save(this, next)
    updateTimerUi(next, now)
  }

  private fun finishSession(s: TimerState) {
    stopBlocking()
    TimerStore.saveFinished(this, s, System.currentTimeMillis())
    TimerStore.clear(this)
    finishedUi = true
    main.removeCallbacks(ticker)
    updateTimerUi(s, SystemClock.elapsedRealtime())
    OverlayBus.emit(
      "onTimerAction",
      mapOf(
        "action" to if (s.status == "completed") "completed" else "aborted",
        "focusedMs" to s.bankedMs.toDouble(),
      ),
    )
    notifyDone(s.status == "completed")
  }

  private fun onPauseResume() {
    val t = timer ?: return
    val now = SystemClock.elapsedRealtime()
    val next = if (t.status == "running") TimerEngine.pause(t, now) else TimerEngine.resume(t, now)
    timer = next
    TimerStore.save(this, next)
    updateTimerUi(next, now)
    OverlayBus.emit("onTimerAction", mapOf("action" to if (next.status == "paused") "paused" else "resumed"))
  }

  private fun onExtend() {
    val t = timer ?: return
    val now = SystemClock.elapsedRealtime()
    val next = TimerEngine.extend(t, 5 * 60_000L, now)
    timer = next
    TimerStore.save(this, next)
    updateTimerUi(next, now)
    OverlayBus.emit("onTimerAction", mapOf("action" to "extended"))
  }

  private fun onStopTapped() {
    val t = timer ?: return
    if (t.isFinished) return
    val s = TimerEngine.stop(t, SystemClock.elapsedRealtime())
    timer = s
    finishSession(s)
  }

  // ───────────────────────── foreground + notification ─────────────────────────

  private fun promote(withProjection: Boolean) {
    val notif = buildNotification("Focus session running")
    try {
      if (Build.VERSION.SDK_INT >= 34) {
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        startForeground(NOTIF_ID, notif, type)
      } else if (Build.VERSION.SDK_INT >= 29 && withProjection) {
        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
      } else {
        startForeground(NOTIF_ID, notif)
      }
    } catch (e: Exception) {
      Log.e(TAG, "startForeground failed", e)
    }
  }

  private fun createChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(CHANNEL_ID, "Focus session", NotificationManager.IMPORTANCE_LOW)
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }
  }

  private fun buildNotification(text: String): Notification {
    val b = if (Build.VERSION.SDK_INT >= 26) {
      Notification.Builder(this, CHANNEL_ID)
    } else {
      @Suppress("DEPRECATION") Notification.Builder(this)
    }
    b.setContentTitle("StudyStreak").setContentText(text).setSmallIcon(applicationInfo.icon).setOngoing(true)
    packageManager.getLaunchIntentForPackage(packageName)?.let {
      b.setContentIntent(PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
    }
    return b.build()
  }

  private fun notifyDone(completed: Boolean) {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.notify(NOTIF_ID, buildNotification(if (completed) "Session complete" else "Session ended"))
  }

  // ───────────────────────── bubble + panel ─────────────────────────

  private fun showBubble() {
    if (bubble != null) {
      bubble?.visibility = View.VISIBLE
      return
    }
    val tv = TextView(this).apply {
      text = "--:--"
      setTextColor(Color.WHITE)
      textSize = 13f
      gravity = Gravity.CENTER
      typeface = Typeface.DEFAULT_BOLD
      background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0xE61A1A22.toInt())
        setStroke(dp(2), ACCENT)
      }
    }
    val lp = overlayParams(dp(64), dp(64), focusable = false).apply {
      gravity = Gravity.TOP or Gravity.START
      x = lastX
      y = lastY
    }
    tv.setOnTouchListener(dragListener(lp) {
      if (finishedUi) shutdown() else showPanel()
    })
    if (addView(tv, lp)) {
      bubble = tv
      bubbleLp = lp
    } else {
      OverlayBus.emit("onTimerAction", mapOf("action" to "permissionLost"))
    }
  }

  private fun showPanel() {
    val b = bubble ?: return
    b.visibility = View.GONE
    val existing = panel
    if (existing != null) {
      panelLp?.let { it.x = lastX; it.y = lastY; updateView(existing, it) }
      existing.visibility = View.VISIBLE
      return
    }

    val lp = overlayParams(dp(280), WindowManager.LayoutParams.WRAP_CONTENT, focusable = false).apply {
      gravity = Gravity.TOP or Gravity.START
      x = lastX
      y = lastY
    }

    val card = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(12), dp(16), dp(16))
      background = GradientDrawable().apply {
        cornerRadius = dp(22).toFloat()
        setColor(CARD)
        setStroke(dp(1), 0xFF2A2A36.toInt())
      }
    }

    val header = LinearLayout(this).apply {
      orientation = LinearLayout.HORIZONTAL
      gravity = Gravity.CENTER_VERTICAL
    }
    header.addView(
      TextView(this).apply { text = "Focus"; setTextColor(MUTED); textSize = 13f },
      LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
    )
    header.addView(pill("–", false) { collapsePanel() })
    header.setOnTouchListener(dragListener(lp) { })
    card.addView(header)

    val time = TextView(this).apply {
      text = "--:--"
      setTextColor(Color.WHITE)
      textSize = 44f
      typeface = Typeface.DEFAULT_BOLD
      gravity = Gravity.CENTER
    }
    val status = TextView(this).apply {
      text = ""
      setTextColor(MUTED)
      textSize = 13f
      gravity = Gravity.CENTER
    }
    card.addView(time)
    card.addView(status)

    val row = LinearLayout(this).apply {
      orientation = LinearLayout.HORIZONTAL
      setPadding(0, dp(12), 0, dp(8))
    }
    val pause = pill("Pause", false) { onPauseResume() }
    row.addView(pause, rowParams())
    row.addView(pill("+5 min", false) { onExtend() }, rowParams())
    row.addView(pill("Stop", false) { onStopTapped() }, rowParams())
    card.addView(row)

    val solve = pill("Circle to solve", true) { beginSolve() }
    card.addView(solve, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

    val close = pill("Close", false) { shutdown() }.apply { visibility = View.GONE }
    card.addView(close, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

    if (addView(card, lp)) {
      panel = card
      panelLp = lp
      panelTime = time
      panelStatus = status
      pauseBtn = pause
      controlsRow = row
      solveBtn = solve
      closeBtn = close
      timer?.let { updateTimerUi(it, SystemClock.elapsedRealtime()) }
    } else {
      b.visibility = View.VISIBLE
    }
  }

  private fun collapsePanel() {
    val p = panel ?: return
    panelLp?.let { lastX = it.x; lastY = it.y }
    p.visibility = View.GONE
    bubbleLp?.let { it.x = lastX; it.y = lastY; bubble?.let { b -> updateView(b, it) } }
    bubble?.visibility = View.VISIBLE
  }

  private fun updateTimerUi(s: TimerState, now: Long) {
    val remaining = TimerEngine.remainingMs(s, now)
    val label = when {
      s.status == "completed" -> "Done"
      s.status == "aborted" -> "Ended"
      else -> formatMs(remaining)
    }
    bubble?.text = label
    panelTime?.text = label
    interstitialTime?.text = label
    panelStatus?.text = when (s.status) {
      "running" -> "Focusing"
      "paused" -> "Paused"
      "completed" -> "Session complete"
      else -> "Session ended"
    }
    pauseBtn?.text = if (s.status == "paused") "Resume" else "Pause"
    val done = s.isFinished
    controlsRow?.visibility = if (done) View.GONE else View.VISIBLE
    solveBtn?.visibility = if (done) View.GONE else View.VISIBLE
    closeBtn?.visibility = if (done) View.VISIBLE else View.GONE
  }

  private fun formatMs(ms: Long): String {
    val totalSec = (ms + 999) / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
  }

  // ───────────────────────── circle to solve ─────────────────────────

  private fun beginSolve() {
    val cfg = SolverConfigStore.load(this)
    if (cfg.apiKey.isEmpty() && cfg.baseUrl == DEFAULT_BASE_URL) {
      toast("Add your API key in StudyStreak settings first.")
      return
    }
    if (!capture.isActive) {
      pendingSolve = true
      try {
        startActivity(
          Intent(this, ScreenCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
      } catch (e: Exception) {
        pendingSolve = false
        toast("Couldn't open the permission prompt. Open StudyStreak and try again.")
        return
      }
      main.postDelayed({
        if (pendingSolve) {
          pendingSolve = false
          toast("Couldn't open the permission prompt. Open StudyStreak and try again.")
        }
      }, 5000)
      return
    }
    grabAndShowLasso()
  }

  private fun handleProjectionGranted(intent: Intent) {
    val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
    val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
      intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
    } else {
      @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
    }
    if (data == null) {
      pendingSolve = false
      return
    }
    promote(true) // Android 14+: projection type must be active before getMediaProjection()
    val (w, h, dpi) = realSize()
    try {
      capture.start(code, data, w, h, dpi) {
        main.post {
          if (!destroyed) {
            promote(false)
            toast("Screen capture stopped.")
          }
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "capture start failed", e)
      pendingSolve = false
      toast("Couldn't start screen capture.")
      return
    }
    if (pendingSolve) {
      pendingSolve = false
      grabAndShowLasso()
    }
  }

  private fun grabAndShowLasso() {
    // Hide our own UI so it isn't in the screenshot, then let a fresh frame arrive.
    bubble?.visibility = View.GONE
    panel?.visibility = View.GONE
    main.postDelayed({
      val (w, h, dpi) = realSize()
      capture.ensureSize(w, h, dpi)
      capture.grab { bmp ->
        if (bmp == null) {
          toast("Couldn't capture the screen.")
          restoreBubble()
        } else {
          showLasso(bmp, looksBlank(bmp))
        }
      }
    }, 320)
  }

  /** True when a sparse sample is entirely black: typical of apps that block capture. */
  private fun looksBlank(b: Bitmap): Boolean {
    val stepX = max(1, b.width / 40)
    val stepY = max(1, b.height / 40)
    var y = 0
    while (y < b.height) {
      var x = 0
      while (x < b.width) {
        if ((b.getPixel(x, y) and 0x00FFFFFF) != 0) return false
        x += stepX
      }
      y += stepY
    }
    return true
  }

  private fun showLasso(bmp: Bitmap, blank: Boolean) {
    val (w, h, _) = realSize()
    val root = FrameLayout(this)
    val match = FrameLayout.LayoutParams.MATCH_PARENT

    root.addView(ImageView(this).apply {
      setImageBitmap(bmp)
      scaleType = ImageView.ScaleType.FIT_XY
    }, FrameLayout.LayoutParams(match, match))
    root.addView(View(this).apply { setBackgroundColor(0x66000000) }, FrameLayout.LayoutParams(match, match))

    val lasso = LassoView(this) { rect -> onLoopDone(bmp, rect, root) }
    root.addView(lasso, FrameLayout.LayoutParams(match, match))

    val hint = TextView(this).apply {
      text = if (blank) "This screen looks blank. The app may block capture." else "Circle the question"
      setTextColor(Color.WHITE)
      textSize = 15f
      typeface = Typeface.DEFAULT_BOLD
      setPadding(dp(16), dp(10), dp(16), dp(10))
      background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0xCC121218.toInt()) }
    }
    root.addView(hint, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
      gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
      topMargin = dp(56)
    })
    lassoHint = hint

    root.addView(pill("Cancel", false) { closeLasso(); restoreBubble() }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
      gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
      bottomMargin = dp(56)
    })

    val lp = overlayParams(w, h, focusable = false).apply {
      gravity = Gravity.TOP or Gravity.START
      x = 0
      y = 0
      flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
      if (Build.VERSION.SDK_INT >= 28) {
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
      }
    }
    if (addView(root, lp)) {
      lassoRoot = root
    } else {
      restoreBubble()
    }
  }

  private fun closeLasso() {
    removeView(lassoRoot)
    lassoRoot = null
    lassoHint = null
  }

  private fun onLoopDone(bmp: Bitmap, rect: RectF, root: FrameLayout) {
    if (rect.width() < dp(40) || rect.height() < dp(40)) {
      lassoHint?.text = "Loop too small, try again"
      return
    }
    val scale = if (root.width > 0) bmp.width.toFloat() / root.width else 1f
    val base64 = try {
      cropToJpegBase64(bmp, rect, scale)
    } catch (e: Exception) {
      Log.e(TAG, "crop failed", e)
      toast("Couldn't read that area.")
      return
    }
    closeLasso()
    showSheet()
    val client = SolverClient(SolverConfigStore.load(this))
    solver = client
    askSolver(client, base64, "Solve this question.")
  }

  private fun cropToJpegBase64(src: Bitmap, r: RectF, scale: Float): String {
    val pad = dp(12)
    val x1 = max(0, (r.left * scale).toInt() - pad)
    val y1 = max(0, (r.top * scale).toInt() - pad)
    val x2 = min(src.width, (r.right * scale).toInt() + pad)
    val y2 = min(src.height, (r.bottom * scale).toInt() + pad)
    var crop = Bitmap.createBitmap(src, x1, y1, max(1, x2 - x1), max(1, y2 - y1))
    val longEdge = max(crop.width, crop.height)
    if (longEdge > 1568) {
      val f = 1568f / longEdge
      crop = Bitmap.createScaledBitmap(crop, max(1, (crop.width * f).toInt()), max(1, (crop.height * f).toInt()), true)
    }
    val out = ByteArrayOutputStream()
    crop.compress(Bitmap.CompressFormat.JPEG, 85, out)
    return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
  }

  // ───────────────────────── answer sheet ─────────────────────────

  private class SheetLayout(ctx: Context, private val onBack: () -> Unit) : LinearLayout(ctx) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
      if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
        onBack()
        return true
      }
      return super.dispatchKeyEvent(event)
    }
  }

  private fun showSheet() {
    val (_, h, _) = realSize()
    val r = dp(22).toFloat()
    val root = SheetLayout(this) { closeSheet() }.apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(12), dp(16), dp(12))
      background = GradientDrawable().apply {
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        setColor(0xFA121218.toInt())
        setStroke(dp(1), 0xFF2A2A36.toInt())
      }
    }

    val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    header.addView(
      TextView(this).apply { text = "Answer"; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD },
      LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
    )
    header.addView(pill("Close", false) { closeSheet() })
    root.addView(header)

    val text = TextView(this).apply {
      this.text = "Solving…"
      setTextColor(0xFFE8E8F0.toInt())
      textSize = 15f
      setLineSpacing(0f, 1.15f)
      setTextIsSelectable(true)
      setPadding(0, dp(10), 0, dp(10))
    }
    val scroll = ScrollView(this).apply { addView(text) }
    root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

    val input = EditText(this).apply {
      hint = "Ask a follow-up"
      setHintTextColor(MUTED)
      setTextColor(Color.WHITE)
      textSize = 14f
      maxLines = 3
      setPadding(dp(12), dp(10), dp(12), dp(10))
      background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(PILL) }
    }
    val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    inputRow.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    inputRow.addView(pill("Send", true) {
      val q = input.text.toString().trim()
      val client = solver
      if (q.isNotEmpty() && client != null && !client.isBusy) {
        input.setText("")
        answerText?.append("\n\nYou: $q\n\n")
        askSolver(client, null, q)
      }
    }.also { (it.layoutParams as? LinearLayout.LayoutParams)?.marginStart = dp(8) })
    root.addView(inputRow)

    val lp = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, (h * 0.62f).toInt(), focusable = true).apply {
      gravity = Gravity.BOTTOM
      softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
    }
    if (addView(root, lp)) {
      sheet = root
      answerText = text
      answerScroll = scroll
      firstDelta = true
    } else {
      restoreBubble()
    }
  }

  private fun askSolver(client: SolverClient, imageBase64: String?, prompt: String) {
    client.ask(
      imageBase64, prompt,
      onDelta = { t ->
        main.post {
          val tv = answerText ?: return@post
          if (firstDelta) {
            tv.text = ""
            firstDelta = false
          }
          tv.append(t)
          answerScroll?.post { answerScroll?.fullScroll(View.FOCUS_DOWN) }
        }
      },
      onDone = { main.post { firstDelta = true } },
      onError = { msg ->
        main.post {
          val tv = answerText ?: return@post
          if (firstDelta) tv.text = ""
          tv.append("\n⚠ $msg")
          firstDelta = true
        }
        OverlayBus.emit("onTimerAction", mapOf("action" to "solverError", "message" to msg))
      },
    )
  }

  private fun closeSheet() {
    removeView(sheet)
    sheet = null
    answerText = null
    answerScroll = null
    solver = null
    restoreBubble()
  }

  private fun restoreBubble() {
    if (destroyed) return
    bubble?.visibility = View.VISIBLE
    panel?.visibility = View.GONE
  }

  // ───────────────────────── app blocking ─────────────────────────

  private class InterstitialLayout(ctx: Context, private val onBack: () -> Unit) : FrameLayout(ctx) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
      if (event.keyCode == KeyEvent.KEYCODE_BACK) {
        if (event.action == KeyEvent.ACTION_UP) onBack()
        return true
      }
      return super.dispatchKeyEvent(event)
    }
  }

  private fun startBlocking() {
    if (BlockStore.mode(this) == "off" || BlockStore.packages(this).isEmpty() || !hasUsageAccess(this)) return
    blocking.disabledForSession = false
    blocking.start()
  }

  private fun stopBlocking() {
    if (::blocking.isInitialized) blocking.stop()
    dismissInterstitial()
  }

  private fun onBlockedForeground(pkg: String) {
    if (interstitial != null && interstitialPkg == pkg) return
    dismissInterstitial()
    val attempt = BlockStore.incAttempts(this)
    showInterstitial(pkg, attempt)
    OverlayBus.emit("onTimerAction", mapOf("action" to "blocked", "message" to pkg))
  }

  private fun goHome() {
    try {
      startActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
      )
    } catch (e: Exception) {
      Log.e(TAG, "goHome failed", e)
    }
  }

  private fun showInterstitial(pkg: String, attempt: Int) {
    val label = try {
      packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
      pkg
    }
    val hard = BlockStore.mode(this) == "hard"
    val (w, h, _) = realSize()

    val root = InterstitialLayout(this) { goHome() }.apply { setBackgroundColor(0xFC0B0B10.toInt()) }
    val col = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      gravity = Gravity.CENTER_HORIZONTAL
      setPadding(dp(32), dp(32), dp(32), dp(32))
    }
    col.addView(TextView(this).apply {
      text = "Stay focused"
      setTextColor(Color.WHITE)
      textSize = 30f
      typeface = Typeface.DEFAULT_BOLD
      gravity = Gravity.CENTER
    })
    col.addView(TextView(this).apply {
      text = "$label is blocked during your focus session."
      setTextColor(MUTED)
      textSize = 15f
      gravity = Gravity.CENTER
      setPadding(0, dp(8), 0, dp(16))
    })
    val time = TextView(this).apply {
      text = timer?.let { formatMs(TimerEngine.remainingMs(it, SystemClock.elapsedRealtime())) } ?: ""
      setTextColor(Color.WHITE)
      textSize = 52f
      typeface = Typeface.DEFAULT_BOLD
      gravity = Gravity.CENTER
    }
    col.addView(time)
    col.addView(TextView(this).apply {
      text = "Attempt #$attempt this session"
      setTextColor(MUTED)
      textSize = 13f
      gravity = Gravity.CENTER
      setPadding(0, dp(4), 0, dp(24))
    })

    val fullWidth = { LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) } }
    col.addView(pill("Back to studying", true) { goHome() }, fullWidth())

    val baseLabel = if (hard) "Emergency exit" else "Continue anyway"
    var left = if (hard) 30 else 10
    var ready = false
    val secondary = pill("$baseLabel ($left)", false) {
      if (ready) {
        if (hard) {
          blocking.disabledForSession = true
          OverlayBus.emit("onTimerAction", mapOf("action" to "emergencyExit"))
          toast("Blocking is off for the rest of this session.")
        } else {
          blocking.snooze(pkg, 5 * 60_000L)
        }
        dismissInterstitial()
      }
    }
    secondary.alpha = 0.4f
    col.addView(secondary, fullWidth())

    val ticker = object : Runnable {
      override fun run() {
        left--
        if (left <= 0) {
          ready = true
          secondary.text = baseLabel
          secondary.alpha = 1f
        } else {
          secondary.text = "$baseLabel ($left)"
          main.postDelayed(this, 1000)
        }
      }
    }
    main.postDelayed(ticker, 1000)

    root.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
      gravity = Gravity.CENTER
    })

    val lp = overlayParams(w, h, focusable = true).apply {
      gravity = Gravity.TOP or Gravity.START
      x = 0
      y = 0
      flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
    }
    if (addView(root, lp)) {
      interstitial = root
      interstitialPkg = pkg
      interstitialTime = time
      interstitialTicker = ticker
    } else {
      main.removeCallbacks(ticker)
    }
  }

  private fun dismissInterstitial() {
    interstitialTicker?.let { main.removeCallbacks(it) }
    interstitialTicker = null
    removeView(interstitial)
    interstitial = null
    interstitialPkg = null
    interstitialTime = null
  }

  // ───────────────────────── window helpers ─────────────────────────

  private fun canDraw(): Boolean = Settings.canDrawOverlays(this)

  private fun overlayParams(w: Int, h: Int, focusable: Boolean): WindowManager.LayoutParams {
    val type = if (Build.VERSION.SDK_INT >= 26) {
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
      @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    }
    var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    return WindowManager.LayoutParams(w, h, type, flags, PixelFormat.TRANSLUCENT)
  }

  private fun addView(v: View, lp: WindowManager.LayoutParams): Boolean = try {
    wm.addView(v, lp)
    true
  } catch (e: Exception) {
    Log.e(TAG, "addView failed (overlay permission revoked?)", e)
    false
  }

  private fun updateView(v: View, lp: WindowManager.LayoutParams) {
    try {
      wm.updateViewLayout(v, lp)
    } catch (e: Exception) {
      // view already removed
    }
  }

  private fun removeView(v: View?) {
    if (v == null) return
    try {
      wm.removeView(v)
    } catch (e: Exception) {
      // not attached
    }
  }

  private fun dragListener(lp: WindowManager.LayoutParams, onTap: () -> Unit): View.OnTouchListener {
    var startX = 0
    var startY = 0
    var touchX = 0f
    var touchY = 0f
    var moved = false
    return View.OnTouchListener { v, e ->
      when (e.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
          startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY; moved = false
          true
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = (e.rawX - touchX).toInt()
          val dy = (e.rawY - touchY).toInt()
          if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
          if (moved) {
            lp.x = startX + dx
            lp.y = startY + dy
            val target: View = if (v.parent is View && v !== bubble) (v.parent as View) else v
            updateView(target, lp)
          }
          true
        }
        MotionEvent.ACTION_UP -> {
          if (moved) { lastX = lp.x; lastY = lp.y } else onTap()
          true
        }
        else -> false
      }
    }
  }

  private fun pill(label: String, filled: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    setTextColor(Color.WHITE)
    textSize = 14f
    gravity = Gravity.CENTER
    typeface = Typeface.DEFAULT_BOLD
    setPadding(dp(12), dp(11), dp(12), dp(11))
    background = GradientDrawable().apply {
      cornerRadius = dp(12).toFloat()
      setColor(if (filled) ACCENT else PILL)
    }
    setOnClickListener { onClick() }
    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
  }

  private fun rowParams(): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) }

  private fun realSize(): Triple<Int, Int, Int> {
    return if (Build.VERSION.SDK_INT >= 30) {
      val b = wm.currentWindowMetrics.bounds
      Triple(b.width(), b.height(), resources.configuration.densityDpi)
    } else {
      val m = DisplayMetrics()
      @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
      Triple(m.widthPixels, m.heightPixels, m.densityDpi)
    }
  }

  private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

  private fun toast(msg: String) {
    Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
  }
}
