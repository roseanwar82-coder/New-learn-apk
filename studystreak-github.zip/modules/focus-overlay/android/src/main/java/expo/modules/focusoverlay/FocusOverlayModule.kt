package expo.modules.focusoverlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class FocusOverlayModule : Module() {
  private val context
    get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

  override fun definition() = ModuleDefinition {
    Name("FocusOverlay")

    Events("onTimerAction")

    OnCreate {
      OverlayBus.listener = { name, payload -> sendEvent(name, payload) }
    }

    OnDestroy {
      OverlayBus.listener = null
    }

    Function("hasOverlayPermission") {
      Settings.canDrawOverlays(context)
    }

    Function("requestOverlayPermission") {
      val intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}"),
      ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
    }

    /** Monotonic clock the timer uses; JS must use the same clock to read state. */
    Function("elapsedRealtime") {
      SystemClock.elapsedRealtime().toDouble()
    }

    Function("startSession") { plannedMs: Double ->
      OverlayService.start(context, plannedMs.toLong())
    }

    /** Tears down the overlay; an unfinished session is recorded as stopped. */
    Function("endSession") {
      OverlayService.stop(context)
    }

    /** Live timer state as JSON (same shape as TimerState in timer.ts), or null. */
    Function("getTimerState") {
      TimerStore.load(context)?.toJson()?.toString()
    }

    /** Returns {"focusedMs","completed","endedAt"} JSON exactly once per finished session. */
    Function("consumeFinishedSession") {
      TimerStore.consumeFinished(context)
    }

    Function("hasUsageAccess") {
      hasUsageAccess(context)
    }

    Function("requestUsageAccess") {
      context.startActivity(
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
      )
    }

    /** mode: off | soft | hard. packagesJson: JSON array of package names. */
    Function("setBlockConfig") { mode: String, packagesJson: String ->
      BlockStore.saveConfig(context, mode, packagesJson)
    }

    /** JSON array of {packageName,label}. Async so a long app list never blocks the JS thread. */
    AsyncFunction("getInstalledApps") {
      listInstalledApps(context)
    }

    Function("isIgnoringBatteryOptimizations") {
      val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
      pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    Function("openBatterySettings") {
      context.startActivity(
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
      )
    }

    Function("setSolverDetail") { detail: String ->
      SolverConfigStore.saveDetail(context, detail)
    }

    Function("setSolverConfig") { apiKey: String, model: String?, baseUrl: String?, detail: String? ->
      SolverConfigStore.save(context, apiKey, model, baseUrl, detail)
    }

    Function("hasSolverConfig") {
      val c = SolverConfigStore.load(context)
      c.apiKey.isNotEmpty() || c.baseUrl != DEFAULT_BASE_URL
    }
  }
}
