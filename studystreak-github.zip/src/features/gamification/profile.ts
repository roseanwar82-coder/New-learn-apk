import { DayKey, toDayKey } from '../../core/dayKey';
import { BadgeContext, Stats, evaluateBadges } from './badges';
import { StreakOutcome, StreakState, applyQualifiedDay, initialStreak, liveStreak } from './streak';
import { gameXp, levelFromXp, sessionXp } from './xp';

export interface Profile {
  xpTotal: number;
  streak: StreakState;
  /** Focus milliseconds per local day. */
  dailyFocusMs: Record<DayKey, number>;
  /** XP earned from games per local day (for the daily cap). */
  gameXpByDay: Record<DayKey, number>;
  stats: Stats;
  unlockedBadges: string[];
  /** Goal shown on the progress ring. */
  dailyGoalMin: number;
  /** Minutes of focus in a day needed to keep the streak. */
  streakThresholdMin: number;
}

export function createProfile(opts: { dailyGoalMin?: number; streakThresholdMin?: number } = {}): Profile {
  return {
    xpTotal: 0,
    streak: initialStreak,
    dailyFocusMs: {},
    gameXpByDay: {},
    stats: {
      totalFocusMs: 0,
      sessionsCompleted: 0,
      cleanSessions: 0,
      longestSessionMs: 0,
      gamesPlayed: 0,
      doubtsSolved: 0,
    },
    unlockedBadges: [],
    dailyGoalMin: opts.dailyGoalMin ?? 60,
    streakThresholdMin: opts.streakThresholdMin ?? 15,
  };
}

export interface SessionResult {
  focusedMs: number;
  completed: boolean;
  blockAttempts: number;
  /** Wall-clock epoch ms when the session ended (used to pick the local day). */
  endedAt: number;
}

export interface SessionOutcome {
  profile: Profile;
  xpEarned: number;
  levelBefore: number;
  levelAfter: number;
  leveledUp: boolean;
  streakOutcome: StreakOutcome;
  newBadges: string[];
}

function badgeContext(p: Profile, streak: StreakState, level: number): BadgeContext {
  return { ...p.stats, currentStreak: streak.current, longestStreak: streak.longest, level };
}

/** Apply a finished session to the profile. Pure: returns a new profile. */
export function applySession(profile: Profile, result: SessionResult, tzOffsetMin: number): SessionOutcome {
  const day = toDayKey(result.endedAt, tzOffsetMin);
  const levelBefore = levelFromXp(profile.xpTotal);

  const live = liveStreak(profile.streak, day);
  const xpEarned = sessionXp(result.focusedMs, live.value);

  const dayTotal = (profile.dailyFocusMs[day] ?? 0) + result.focusedMs;
  const stats: Stats = {
    ...profile.stats,
    totalFocusMs: profile.stats.totalFocusMs + result.focusedMs,
    sessionsCompleted: profile.stats.sessionsCompleted + (result.completed ? 1 : 0),
    cleanSessions:
      profile.stats.cleanSessions + (result.completed && result.blockAttempts === 0 ? 1 : 0),
    longestSessionMs: Math.max(profile.stats.longestSessionMs, result.focusedMs),
  };

  let streak = profile.streak;
  let streakOutcome: StreakOutcome = 'unchanged';
  const thresholdMs = profile.streakThresholdMin * 60_000;
  if (dayTotal >= thresholdMs) {
    const r = applyQualifiedDay(streak, day, dayTotal, thresholdMs);
    streak = r.state;
    streakOutcome = r.outcome;
  }

  const xpTotal = profile.xpTotal + xpEarned;
  const levelAfter = levelFromXp(xpTotal);
  const interim: Profile = { ...profile, stats };
  const newBadges = evaluateBadges(badgeContext(interim, streak, levelAfter), profile.unlockedBadges);

  return {
    profile: {
      ...profile,
      xpTotal,
      streak,
      stats,
      dailyFocusMs: { ...profile.dailyFocusMs, [day]: dayTotal },
      unlockedBadges: [...profile.unlockedBadges, ...newBadges],
    },
    xpEarned,
    levelBefore,
    levelAfter,
    leveledUp: levelAfter > levelBefore,
    streakOutcome,
    newBadges,
  };
}

export interface GameOutcome {
  profile: Profile;
  xpEarned: number;
  newBadges: string[];
}

/** Record a finished focus game (score01 normalized to 0..1). Daily game XP is capped. */
export function applyGame(profile: Profile, score01: number, endedAt: number, tzOffsetMin: number): GameOutcome {
  const day = toDayKey(endedAt, tzOffsetMin);
  const earnedToday = profile.gameXpByDay[day] ?? 0;
  const xpEarned = gameXp(score01, earnedToday);
  const stats: Stats = { ...profile.stats, gamesPlayed: profile.stats.gamesPlayed + 1 };
  const xpTotal = profile.xpTotal + xpEarned;
  const interim: Profile = { ...profile, stats };
  const newBadges = evaluateBadges(
    badgeContext(interim, profile.streak, levelFromXp(xpTotal)),
    profile.unlockedBadges,
  );
  return {
    profile: {
      ...profile,
      xpTotal,
      stats,
      gameXpByDay: { ...profile.gameXpByDay, [day]: earnedToday + xpEarned },
      unlockedBadges: [...profile.unlockedBadges, ...newBadges],
    },
    xpEarned,
    newBadges,
  };
}
