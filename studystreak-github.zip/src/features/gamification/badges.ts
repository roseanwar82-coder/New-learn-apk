export type BadgeTier = 'bronze' | 'silver' | 'gold';

export interface Stats {
  totalFocusMs: number;
  sessionsCompleted: number;
  /** Completed sessions with zero blocked-app attempts. */
  cleanSessions: number;
  longestSessionMs: number;
  gamesPlayed: number;
  doubtsSolved: number;
}

export interface BadgeContext extends Stats {
  currentStreak: number;
  longestStreak: number;
  level: number;
}

export interface BadgeDef {
  id: string;
  title: string;
  description: string;
  tier: BadgeTier;
  earned: (c: BadgeContext) => boolean;
}

const HOUR = 3_600_000;

export const BADGES: BadgeDef[] = [
  { id: 'first_session', title: 'First Step', description: 'Complete your first session', tier: 'bronze', earned: (c) => c.sessionsCompleted >= 1 },
  { id: 'hours_1', title: 'Warmed Up', description: '1 hour of total focus', tier: 'bronze', earned: (c) => c.totalFocusMs >= HOUR },
  { id: 'hours_10', title: 'Deep Diver', description: '10 hours of total focus', tier: 'silver', earned: (c) => c.totalFocusMs >= 10 * HOUR },
  { id: 'hours_100', title: 'Centurion', description: '100 hours of total focus', tier: 'gold', earned: (c) => c.totalFocusMs >= 100 * HOUR },
  { id: 'streak_3', title: 'On a Roll', description: '3-day streak', tier: 'bronze', earned: (c) => c.longestStreak >= 3 },
  { id: 'streak_7', title: 'Week Warrior', description: '7-day streak', tier: 'silver', earned: (c) => c.longestStreak >= 7 },
  { id: 'streak_30', title: 'Unbreakable', description: '30-day streak', tier: 'gold', earned: (c) => c.longestStreak >= 30 },
  { id: 'marathon', title: 'Marathoner', description: 'One 90+ minute session', tier: 'silver', earned: (c) => c.longestSessionMs >= 90 * 60_000 },
  { id: 'clean_5', title: 'No Distractions', description: '5 sessions with no blocked-app attempts', tier: 'silver', earned: (c) => c.cleanSessions >= 5 },
  { id: 'level_5', title: 'Level 5', description: 'Reach level 5', tier: 'bronze', earned: (c) => c.level >= 5 },
  { id: 'level_10', title: 'Level 10', description: 'Reach level 10', tier: 'silver', earned: (c) => c.level >= 10 },
  { id: 'games_10', title: 'Sharp Mind', description: 'Play 10 focus games', tier: 'bronze', earned: (c) => c.gamesPlayed >= 10 },
  { id: 'doubts_25', title: 'Curious Mind', description: 'Solve 25 doubts', tier: 'silver', earned: (c) => c.doubtsSolved >= 25 },
];

/** Returns ids of badges newly earned (not already unlocked). Pure. */
export function evaluateBadges(ctx: BadgeContext, unlocked: readonly string[]): string[] {
  const have = new Set(unlocked);
  return BADGES.filter((b) => !have.has(b.id) && b.earned(ctx)).map((b) => b.id);
}
