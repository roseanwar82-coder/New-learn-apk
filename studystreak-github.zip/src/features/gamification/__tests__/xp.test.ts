import {
  gameXp,
  levelFromXp,
  levelProgress,
  sessionXp,
  streakMultiplier,
  xpToReachLevel,
} from '../xp';

const MIN = 60_000;

describe('xp', () => {
  it('streak multiplier grows 5% a day and caps at 1.5x', () => {
    expect(streakMultiplier(0)).toBe(1);
    expect(streakMultiplier(3)).toBe(1.15);
    expect(streakMultiplier(10)).toBe(1.5);
    expect(streakMultiplier(100)).toBe(1.5);
    expect(streakMultiplier(-4)).toBe(1);
  });

  it('awards 10 XP per full focus minute, floors partial minutes', () => {
    expect(sessionXp(25 * MIN, 0)).toBe(250);
    expect(sessionXp(25 * MIN, 10)).toBe(375);
    expect(sessionXp(59_999, 0)).toBe(0);
    expect(sessionXp(90_000, 0)).toBe(10);
    expect(sessionXp(-5, 0)).toBe(0);
  });

  it('game XP scales with score and respects the daily cap', () => {
    expect(gameXp(0, 0)).toBe(20);
    expect(gameXp(0.5, 0)).toBe(40);
    expect(gameXp(1, 0)).toBe(60);
    expect(gameXp(7, 0)).toBe(60);
    expect(gameXp(1, 140)).toBe(10);
    expect(gameXp(1, 150)).toBe(0);
    expect(gameXp(1, 999)).toBe(0);
  });

  it('level thresholds', () => {
    expect(xpToReachLevel(1)).toBe(0);
    expect(xpToReachLevel(2)).toBe(100);
    expect(xpToReachLevel(3)).toBe(303);
  });

  it('levelFromXp is consistent with thresholds at every level', () => {
    expect(levelFromXp(0)).toBe(1);
    expect(levelFromXp(99)).toBe(1);
    expect(levelFromXp(100)).toBe(2);
    expect(levelFromXp(302)).toBe(2);
    expect(levelFromXp(303)).toBe(3);
    for (let l = 1; l <= 60; l++) {
      const t = xpToReachLevel(l);
      expect(levelFromXp(t)).toBe(l);
      if (t > 0) expect(levelFromXp(t - 1)).toBe(l - 1);
    }
  });

  it('levelProgress reports fraction into the level', () => {
    const p = levelProgress(100 + 101); // level 2 spans 100..303 (203 XP)
    expect(p.level).toBe(2);
    expect(p.intoLevel).toBe(101);
    expect(p.needed).toBe(203);
    expect(p.fraction).toBeCloseTo(101 / 203, 5);
  });
});
