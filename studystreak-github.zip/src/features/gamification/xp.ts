export const XP_PER_FOCUS_MINUTE = 10;
export const STREAK_BONUS_PER_DAY = 0.05;
export const MAX_STREAK_BONUS = 0.5;
export const GAME_XP_MIN = 20;
export const GAME_XP_MAX = 60;
export const DAILY_GAME_XP_CAP = 150;

/** 1.0 at no streak, +5% per streak day, capped at 1.5x. */
export function streakMultiplier(streakDays: number): number {
  const bonus = Math.min(MAX_STREAK_BONUS, Math.max(0, streakDays) * STREAK_BONUS_PER_DAY);
  return Math.round((1 + bonus) * 100) / 100;
}

/** XP for verified focus time. Partial minutes are floored. */
export function sessionXp(focusedMs: number, streakDays: number): number {
  const minutes = Math.floor(Math.max(0, focusedMs) / 60_000);
  return Math.round(minutes * XP_PER_FOCUS_MINUTE * streakMultiplier(streakDays));
}

/**
 * XP for a focus game. score01 is a normalized 0..1 result.
 * Capped per day so games cannot be farmed.
 */
export function gameXp(score01: number, earnedTodayFromGames: number): number {
  const s = Math.min(1, Math.max(0, score01));
  const base = Math.round(GAME_XP_MIN + (GAME_XP_MAX - GAME_XP_MIN) * s);
  const remaining = Math.max(0, DAILY_GAME_XP_CAP - earnedTodayFromGames);
  return Math.min(base, remaining);
}

/** Cumulative XP needed to reach level L (level 1 = 0 XP). */
export function xpToReachLevel(level: number): number {
  if (level <= 1) return 0;
  return Math.round(100 * Math.pow(level - 1, 1.6));
}

export function levelFromXp(xp: number): number {
  const safe = Math.max(0, xp);
  let level = Math.floor(Math.pow(safe / 100, 1 / 1.6)) + 1;
  while (xpToReachLevel(level + 1) <= safe) level++;
  while (level > 1 && xpToReachLevel(level) > safe) level--;
  return level;
}

export interface LevelProgress {
  level: number;
  intoLevel: number;
  needed: number;
  fraction: number;
}

export function levelProgress(xp: number): LevelProgress {
  const level = levelFromXp(xp);
  const start = xpToReachLevel(level);
  const needed = xpToReachLevel(level + 1) - start;
  const intoLevel = Math.max(0, xp) - start;
  return { level, intoLevel, needed, fraction: needed > 0 ? intoLevel / needed : 0 };
}
