#!/usr/bin/env bash
# Generates the Expo app around the code in this folder.
#   bash scripts/bootstrap.sh [target-dir]
# Needs Node 20+ and internet access. Default target: ../studystreak-app
set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
APP_DIR="${1:-$SRC_DIR/../studystreak-app}"

if [ -e "$APP_DIR" ]; then
  echo "Target $APP_DIR already exists. Pick another folder or delete it first." >&2
  exit 1
fi

echo "==> Creating Expo app at $APP_DIR"
npx --yes create-expo-app@latest "$APP_DIR" --template default --yes
APP_DIR="$(cd "$APP_DIR" && pwd)"

echo "==> Removing the starter template's screens (StudyStreak replaces them)"
cd "$APP_DIR"
rm -rf app app-example components hooks constants src/app src/components src/hooks src/constants scripts/reset-project.js

echo "==> Copying StudyStreak source, native module and EAS config"
mkdir -p src
cp -R "$SRC_DIR/src/." "$APP_DIR/src/"
cp -R "$SRC_DIR/modules" "$APP_DIR/modules"
cp "$SRC_DIR/eas.json" "$APP_DIR/eas.json"
mkdir -p scripts && cp "$SRC_DIR/scripts/patch-project.js" scripts/

echo "==> Installing dependencies (versions matched to this Expo SDK)"
npx expo install zustand @react-native-async-storage/async-storage expo-dev-client expo-notifications expo-haptics expo-status-bar react-native-safe-area-context
npm install --save-dev jest jest-expo @types/jest

node scripts/patch-project.js "$APP_DIR"

echo
echo "Done. Next steps:"
echo "  1) npm test                                  # all logic tests should pass"
echo "  2) npx tsc --noEmit                          # type check"
echo "  3) npm i -g eas-cli && eas login"
echo "  4) eas build -p android --profile preview    # builds an installable APK in the cloud"
echo "     (or, with Android Studio installed: npx expo run:android on a connected phone)"
echo "See modules/focus-overlay/README.md for what to verify on the phone."
