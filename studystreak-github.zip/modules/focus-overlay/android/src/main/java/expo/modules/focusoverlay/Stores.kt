package expo.modules.focusoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

private const val PREFS = "focus_overlay"

/** Persists the live timer so the service (and JS) can recover after the app is killed. */
object TimerStore {
  private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun save(c: Context, s: TimerState) {
    prefs(c).edit().putString("timer", s.toJson().toString()).apply()
  }

  fun load(c: Context): TimerState? {
    val raw = prefs(c).getString("timer", null) ?: return null
    return try {
      TimerState.fromJson(JSONObject(raw))
    } catch (e: Exception) {
      null
    }
  }

  fun clear(c: Context) {
    prefs(c).edit().remove("timer").apply()
  }

  /** Stored once when a session ends; JS reads it exactly once via consumeFinished. */
  fun saveFinished(c: Context, s: TimerState, endedAtEpochMs: Long) {
    val o = JSONObject()
      .put("focusedMs", s.bankedMs)
      .put("completed", s.status == "completed")
      .put("endedAt", endedAtEpochMs)
      .put("blockAttempts", BlockStore.attempts(c))
    prefs(c).edit().putString("finished", o.toString()).apply()
  }

  fun consumeFinished(c: Context): String? {
    val p = prefs(c)
    val v = p.getString("finished", null)
    if (v != null) p.edit().remove("finished").apply()
    return v
  }
}

const val DEFAULT_BASE_URL = "https://api.anthropic.com"
const val DEFAULT_MODEL = "claude-sonnet-5-5"

data class SolverConfig(
  val apiKey: String,
  val model: String,
  val baseUrl: String,
  /** "steps" or "short" */
  val detail: String,
)

/**
 * NOTE: stored in app-private SharedPreferences. For a personal APK that is
 * acceptable; for distribution use a proxy (baseUrl) so no key ships on devices.
 */
object SolverConfigStore {
  private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun save(c: Context, apiKey: String, model: String?, baseUrl: String?, detail: String?) {
    prefs(c).edit()
      .putString("apiKey", apiKey)
      .putString("model", model?.takeIf { it.isNotBlank() } ?: DEFAULT_MODEL)
      .putString("baseUrl", baseUrl?.takeIf { it.isNotBlank() } ?: DEFAULT_BASE_URL)
      .putString("detail", if (detail == "short") "short" else "steps")
      .apply()
  }

  fun saveDetail(c: Context, detail: String) {
    prefs(c).edit().putString("detail", if (detail == "short") "short" else "steps").apply()
  }

  fun load(c: Context): SolverConfig {
    val p = prefs(c)
    return SolverConfig(
      apiKey = p.getString("apiKey", "") ?: "",
      model = p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL,
      baseUrl = p.getString("baseUrl", DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL,
      detail = p.getString("detail", "steps") ?: "steps",
    )
  }
}

/** Blocked-app list, mode and per-session attempt counter (read by the service). */
object BlockStore {
  private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun saveConfig(c: Context, mode: String, packagesJson: String) {
    val m = if (mode == "soft" || mode == "hard") mode else "off"
    prefs(c).edit().putString("blockMode", m).putString("blockPkgs", packagesJson).apply()
  }

  fun mode(c: Context): String = prefs(c).getString("blockMode", "off") ?: "off"

  fun packages(c: Context): Set<String> {
    val raw = prefs(c).getString("blockPkgs", "[]") ?: "[]"
    return try {
      val a = JSONArray(raw)
      (0 until a.length()).map { a.getString(it) }.toSet()
    } catch (e: Exception) {
      emptySet()
    }
  }

  fun resetAttempts(c: Context) {
    prefs(c).edit().putInt("blockAttempts", 0).apply()
  }

  fun attempts(c: Context): Int = prefs(c).getInt("blockAttempts", 0)

  fun incAttempts(c: Context): Int {
    val n = attempts(c) + 1
    prefs(c).edit().putInt("blockAttempts", n).apply()
    return n
  }
}

/** Service -> module event channel (module registers a listener while alive). */
object OverlayBus {
  @Volatile
  var listener: ((String, Map<String, Any?>) -> Unit)? = null

  fun emit(name: String, payload: Map<String, Any?>) {
    listener?.invoke(name, payload)
  }
}
