package expo.modules.focusoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Freehand loop. When the finger lifts, reports the loop's bounding box (view coordinates). */
class LassoView(
  context: Context,
  private val onLoop: (RectF) -> Unit,
) : View(context) {
  private val path = Path()
  private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    strokeWidth = 14f
    strokeCap = Paint.Cap.ROUND
    strokeJoin = Paint.Join.ROUND
    color = Color.argb(70, 139, 124, 255)
  }
  private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    strokeWidth = 6f
    strokeCap = Paint.Cap.ROUND
    strokeJoin = Paint.Join.ROUND
    color = Color.WHITE
  }

  fun clear() {
    path.reset()
    invalidate()
  }

  override fun onDraw(canvas: Canvas) {
    canvas.drawPath(path, glow)
    canvas.drawPath(path, line)
  }

  override fun onTouchEvent(e: MotionEvent): Boolean {
    when (e.actionMasked) {
      MotionEvent.ACTION_DOWN -> {
        path.reset()
        path.moveTo(e.x, e.y)
      }
      MotionEvent.ACTION_MOVE -> path.lineTo(e.x, e.y)
      MotionEvent.ACTION_UP -> {
        path.close()
        val r = RectF()
        path.computeBounds(r, true)
        invalidate()
        onLoop(r)
      }
      MotionEvent.ACTION_CANCEL -> path.reset()
      else -> return false
    }
    invalidate()
    return true
  }
}
