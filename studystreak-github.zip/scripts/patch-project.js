// Adjusts the freshly generated Expo app: name, Android package, jest config.
// Usage: node scripts/patch-project.js <appDir>
const fs = require('fs');
const path = require('path');

const dir = process.argv[2];
if (!dir) {
  console.error('usage: node patch-project.js <appDir>');
  process.exit(1);
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}
function writeJson(p, o) {
  fs.writeFileSync(p, JSON.stringify(o, null, 2) + '\n');
}

// package.json: test script + jest preset
const pkgPath = path.join(dir, 'package.json');
const pkg = readJson(pkgPath);
pkg.scripts = { ...(pkg.scripts || {}), test: 'jest' };
pkg.jest = {
  preset: 'jest-expo',
  testPathIgnorePatterns: ['/node_modules/', '/android/'],
};
writeJson(pkgPath, pkg);

// app.json: identity, dark UI, Android only
const appPath = path.join(dir, 'app.json');
const app = readJson(appPath);
const e = app.expo || (app.expo = {});
e.name = 'StudyStreak';
e.slug = 'studystreak';
e.scheme = 'studystreak';
e.userInterfaceStyle = 'dark';
e.orientation = 'portrait';
e.platforms = ['android'];
delete e.ios;
e.android = { ...(e.android || {}), package: 'com.studystreak.app' };
const plugins = Array.isArray(e.plugins) ? e.plugins : [];
for (const name of ['expo-router', 'expo-notifications']) {
  const has = plugins.some((p) => (Array.isArray(p) ? p[0] : p) === name);
  if (!has) plugins.push(name);
}
e.plugins = plugins;
writeJson(appPath, app);

console.log('Patched package.json and app.json');
