import { StreakState, applyQualifiedDay, initialStreak, liveStreak } from '../streak';

const MIN = 60_000;
const GOAL = 15 * MIN;

function st(over: Partial<StreakState>): StreakState {
  return { ...initialStreak, ...over };
}

describe('streak', () => {
  it('starts, continues and ignores repeat calls on the same day', () => {
    let r = applyQualifiedDay(initialStreak, '2026-10-01', GOAL, GOAL);
    expect(r.outcome).toBe('started');
    expect(r.state.current).toBe(1);

    r = applyQualifiedDay(r.state, '2026-10-02', GOAL, GOAL);
    expect(r.outcome).toBe('continued');
    expect(r.state.current).toBe(2);

    const again = applyQualifiedDay(r.state, '2026-10-02', GOAL, GOAL);
    expect(again.outcome).toBe('unchanged');
    expect(again.state).toBe(r.state);
  });

  it('earns a freeze token on every 7th day, max 2', () => {
    let s = initialStreak;
    for (let d = 1; d <= 7; d++) {
      s = applyQualifiedDay(s, `2026-10-0${d}`, GOAL, GOAL).state;
    }
    expect(s.current).toBe(7);
    expect(s.freezeTokens).toBe(1);

    s = st({ current: 20, longest: 20, lastQualifiedDay: '2026-10-20', freezeTokens: 2 });
    s = applyQualifiedDay(s, '2026-10-21', GOAL, GOAL).state; // 21 = multiple of 7
    expect(s.freezeTokens).toBe(2);
  });

  it('auto-spends a freeze token to cover one missed day', () => {
    const s = st({ current: 7, longest: 7, lastQualifiedDay: '2026-10-07', freezeTokens: 1 });
    const r = applyQualifiedDay(s, '2026-10-09', GOAL, GOAL);
    expect(r.outcome).toBe('frozen');
    expect(r.state.current).toBe(8);
    expect(r.state.freezeTokens).toBe(0);
    expect(r.state.freezesUsed).toEqual(['2026-10-08']);
  });

  it('spends one token per missed day', () => {
    const s = st({ current: 5, longest: 5, lastQualifiedDay: '2026-10-05', freezeTokens: 2 });
    const r = applyQualifiedDay(s, '2026-10-08', GOAL, GOAL);
    expect(r.outcome).toBe('frozen');
    expect(r.state.freezeTokens).toBe(0);
    expect(r.state.freezesUsed).toEqual(['2026-10-06', '2026-10-07']);
  });

  it('resets when the gap is bigger than the freeze tokens, keeping longest', () => {
    const s = st({ current: 3, longest: 3, lastQualifiedDay: '2026-10-03', freezeTokens: 0 });
    const r = applyQualifiedDay(s, '2026-10-06', GOAL, GOAL);
    expect(r.outcome).toBe('reset');
    expect(r.state.current).toBe(1);
    expect(r.state.longest).toBe(3);
  });

  it('recovers a single missed day with a 2x-goal day', () => {
    const s = st({ current: 5, longest: 5, lastQualifiedDay: '2026-10-03' });
    const r = applyQualifiedDay(s, '2026-10-05', GOAL * 2, GOAL);
    expect(r.outcome).toBe('recovered');
    expect(r.state.current).toBe(6);
    expect(r.state.lastRecoveryDay).toBe('2026-10-05');
  });

  it('does not recover with only 1x goal, or for multi-day gaps', () => {
    const s = st({ current: 5, longest: 5, lastQualifiedDay: '2026-10-03' });
    expect(applyQualifiedDay(s, '2026-10-05', GOAL, GOAL).outcome).toBe('reset');
    expect(applyQualifiedDay(s, '2026-10-06', GOAL * 3, GOAL).outcome).toBe('reset');
  });

  it('recovery has a 30-day cooldown', () => {
    const s = st({
      current: 6,
      longest: 6,
      lastQualifiedDay: '2026-10-05',
      lastRecoveryDay: '2026-10-05',
    });
    expect(applyQualifiedDay(s, '2026-10-07', GOAL * 2, GOAL).outcome).toBe('reset');
    const later = st({ ...s, lastQualifiedDay: '2026-11-10' });
    expect(applyQualifiedDay(later, '2026-11-12', GOAL * 2, GOAL).outcome).toBe('recovered');
  });

  it('ignores a day earlier than the last qualified day', () => {
    const s = st({ current: 4, longest: 4, lastQualifiedDay: '2026-10-10' });
    expect(applyQualifiedDay(s, '2026-10-08', GOAL, GOAL).outcome).toBe('unchanged');
  });

  describe('liveStreak', () => {
    const base = st({ current: 4, longest: 4, lastQualifiedDay: '2026-10-10' });

    it('shows qualified today / at risk', () => {
      expect(liveStreak(base, '2026-10-10')).toMatchObject({ value: 4, qualifiedToday: true, atRisk: false });
      expect(liveStreak(base, '2026-10-11')).toMatchObject({ value: 4, atRisk: true });
    });

    it('stays alive when freeze tokens cover the gap', () => {
      const s = st({ ...base, freezeTokens: 1 });
      expect(liveStreak(s, '2026-10-12').value).toBe(4);
    });

    it('flags a recoverable one-day miss', () => {
      expect(liveStreak(base, '2026-10-12')).toMatchObject({ value: 4, recoverable: true });
    });

    it('is 0 once broken or never started', () => {
      expect(liveStreak(base, '2026-10-20').value).toBe(0);
      expect(liveStreak(initialStreak, '2026-10-20').value).toBe(0);
    });
  });
});
