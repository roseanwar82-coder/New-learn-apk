import { BADGES, evaluateBadges } from '../badges';
import { applyGame, applySession, createProfile } from '../profile';

const MIN = 60_000;
const IST = 330;
const at = (d: number, h = 12) => Date.UTC(2026, 9, d, h - 5, 30); // d Oct 2026, h:00 IST

describe('badges', () => {
  it('has unique ids', () => {
    const ids = BADGES.map((b) => b.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('returns only newly earned badges', () => {
    const ctx = {
      totalFocusMs: 3_600_000, sessionsCompleted: 1, cleanSessions: 1, longestSessionMs: 3_600_000,
      gamesPlayed: 0, doubtsSolved: 0, currentStreak: 1, longestStreak: 1, level: 1,
    };
    expect(evaluateBadges(ctx, []).sort()).toEqual(['first_session', 'hours_1']);
    expect(evaluateBadges(ctx, ['first_session'])).toEqual(['hours_1']);
  });
});

describe('applySession', () => {
  it('awards XP, qualifies the day and unlocks first badges', () => {
    const p = createProfile();
    const r = applySession(p, { focusedMs: 25 * MIN, completed: true, blockAttempts: 0, endedAt: at(1) }, IST);
    expect(r.xpEarned).toBe(250);
    expect(r.profile.xpTotal).toBe(250);
    expect(r.streakOutcome).toBe('started');
    expect(r.profile.streak.current).toBe(1);
    expect(r.newBadges).toContain('first_session');
    expect(r.levelBefore).toBe(1);
    expect(r.levelAfter).toBe(2); // 250 XP: level 3 needs 303
    expect(r.leveledUp).toBe(true);
    expect(p.xpTotal).toBe(0); // input not mutated
  });

  it('does not qualify the streak until the daily threshold is met', () => {
    let r = applySession(createProfile(), { focusedMs: 10 * MIN, completed: true, blockAttempts: 0, endedAt: at(1) }, IST);
    expect(r.profile.streak.current).toBe(0);
    r = applySession(r.profile, { focusedMs: 6 * MIN, completed: true, blockAttempts: 0, endedAt: at(1, 15) }, IST);
    expect(r.profile.streak.current).toBe(1);
    expect(r.profile.dailyFocusMs['2026-10-01']).toBe(16 * MIN);
  });

  it('applies the streak multiplier from the live streak', () => {
    let p = createProfile();
    for (let d = 1; d <= 3; d++) {
      p = applySession(p, { focusedMs: 20 * MIN, completed: true, blockAttempts: 0, endedAt: at(d) }, IST).profile;
    }
    expect(p.streak.current).toBe(3);
    const r = applySession(p, { focusedMs: 20 * MIN, completed: true, blockAttempts: 0, endedAt: at(4) }, IST);
    expect(r.xpEarned).toBe(230); // 200 base * 1.15
  });

  it('uses the local day (IST) for late-night sessions', () => {
    // 23:30 IST on Oct 1 is 18:00 UTC Oct 1; 00:30 IST Oct 2 is 19:00 UTC Oct 1
    const lateOct1 = Date.UTC(2026, 9, 1, 18, 0);
    const earlyOct2 = Date.UTC(2026, 9, 1, 19, 0);
    let p = applySession(createProfile(), { focusedMs: 20 * MIN, completed: true, blockAttempts: 0, endedAt: lateOct1 }, IST).profile;
    p = applySession(p, { focusedMs: 20 * MIN, completed: true, blockAttempts: 0, endedAt: earlyOct2 }, IST).profile;
    expect(p.streak.current).toBe(2);
  });

  it('counts aborted sessions toward focus time but not clean/completed stats', () => {
    const r = applySession(createProfile(), { focusedMs: 12 * MIN, completed: false, blockAttempts: 2, endedAt: at(1) }, IST);
    expect(r.xpEarned).toBe(120);
    expect(r.profile.stats.sessionsCompleted).toBe(0);
    expect(r.profile.stats.cleanSessions).toBe(0);
    expect(r.profile.stats.totalFocusMs).toBe(12 * MIN);
  });

  it('does not re-award badges already unlocked', () => {
    const first = applySession(createProfile(), { focusedMs: 25 * MIN, completed: true, blockAttempts: 0, endedAt: at(1) }, IST);
    const second = applySession(first.profile, { focusedMs: 25 * MIN, completed: true, blockAttempts: 0, endedAt: at(1, 18) }, IST);
    expect(second.newBadges).not.toContain('first_session');
    expect(new Set(second.profile.unlockedBadges).size).toBe(second.profile.unlockedBadges.length);
  });
});

describe('applyGame', () => {
  it('awards game XP and enforces the daily cap', () => {
    let p = createProfile();
    let total = 0;
    for (let i = 0; i < 6; i++) {
      const r = applyGame(p, 1, at(1, 9 + i), IST);
      p = r.profile;
      total += r.xpEarned;
    }
    expect(total).toBe(150); // 60 + 60 + 30 then 0s
    expect(p.xpTotal).toBe(150);
    expect(p.stats.gamesPlayed).toBe(6);
  });

  it('resets the cap on a new day', () => {
    let p = createProfile();
    for (let i = 0; i < 3; i++) p = applyGame(p, 1, at(1), IST).profile;
    expect(applyGame(p, 1, at(2), IST).xpEarned).toBe(60);
  });
});
