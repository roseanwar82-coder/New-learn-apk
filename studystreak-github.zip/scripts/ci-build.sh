#!/usr/bin/env bash
# Runs on the GitHub Actions runner: generates the Expo app, checks it, builds a release APK.
# The APK is signed with the default debug key, which is fine for installing on your own phone.
set -euo pipefail

SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP="$SRC/../studystreak-app"
export CI=1

bash "$SRC/scripts/bootstrap.sh" "$APP"
cd "$APP"

# Checks are reported as warnings so a small test/type issue doesn't block your first APK.
npm test -- --ci || echo "::warning::Some tests failed. See the log."
npx tsc --noEmit || echo "::warning::Type check reported errors. See the log."

npx expo prebuild --platform android --no-install

cd android
chmod +x gradlew
./gradlew assembleRelease -PreactNativeArchitectures=arm64-v8a --no-daemon

APK="$(find app/build/outputs/apk/release -name '*.apk' | head -n 1)"
if [ -z "$APK" ]; then
  echo "No APK produced" >&2
  exit 1
fi
cp "$APK" "$SRC/StudyStreak.apk"
echo "Built $(du -h "$SRC/StudyStreak.apk" | cut -f1) APK"
