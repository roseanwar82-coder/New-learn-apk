import { Stack, useRootNavigationState, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { Alert, AppState } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { FocusOverlay } from '../native/focusOverlay';
import { useHydrated, useStore } from '../state/store';
import { colors } from '../ui/theme';

export default function RootLayout() {
  const hydrated = useHydrated();
  const navState = useRootNavigationState();
  const ready = hydrated && !!navState?.key;

  const router = useRouter();
  const segments = useSegments();
  const onboarded = useStore((s) => s.onboarded);
  const ingestFinished = useStore((s) => s.ingestFinished);

  // Pull finished sessions in on launch, on foreground, and when the overlay says one ended.
  useEffect(() => {
    if (!ready) return;
    const check = () => {
      if (ingestFinished()) router.push('/complete');
    };
    check();
    const appSub = AppState.addEventListener('change', (st) => {
      if (st === 'active') check();
    });
    let evSub: { remove(): void } | null = null;
    try {
      evSub = FocusOverlay.onEvent((e) => {
        if (e.action === 'completed' || e.action === 'aborted') check();
        if (e.action === 'permissionLost') {
          Alert.alert('Overlay permission lost', 'Allow "Display over other apps" again to keep the floating timer.');
        }
      });
    } catch {
      // native module unavailable
    }
    return () => {
      appSub.remove();
      evSub?.remove();
    };
  }, [ready]);

  useEffect(() => {
    if (!ready) return;
    if (!onboarded && segments[0] !== 'onboarding') router.replace('/onboarding');
  }, [ready, onboarded, segments]);

  if (!hydrated) return null;

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="onboarding" options={{ gestureEnabled: false }} />
        <Stack.Screen name="complete" options={{ gestureEnabled: false }} />
      </Stack>
    </SafeAreaProvider>
  );
}
